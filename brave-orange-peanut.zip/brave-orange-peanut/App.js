import { Text, SafeAreaView, StyleSheet,  View, TextInput, Button } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
    <View style={styles.header}>
    </View>
    <View style={styles.viewinputs}>

      <View style={styles.inputs}>
        <Text>Nome do usuário...</Text>
        <TextInput st></TextInput>
      </View>

      <View style={styles.inputs}>
        <Text>Senha...</Text>
        <TextInput></TextInput>
      </View>
    <View>
      <Button>
      </Button>
    </View>

    </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    display: 'flex',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'blue',
    padding: 8,
  },
  header: {
    position: 'fixed',
    top: 0,
    width: '100%',
    height: 100,
    backgroundColor: 'red',
  },
  viewinputs:{
    display:'flex',
    justifyContent:'space-around',
    height: 400,
    width: '80%',
    backgroundColor: 'pink',
  },
  inputs:{
    backgroundColor:'orange',
    alignItems: 'center',
  },
});
